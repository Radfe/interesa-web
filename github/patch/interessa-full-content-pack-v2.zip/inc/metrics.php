<?php
declare(strict_types=1);
/**
 * Jednoduché počítadlo zobrazení článkov + rebríček najčítanejších.
 * Ukladá do storage/views.json (associative array: slug => count).
 */
function __interessa_views_path(): string {
    return __DIR__ . '/../storage/views.json';
}
function interessa_count_view(string $slug): void {
    $file = __interessa_views_path();
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $data = [];
    if (is_file($file)) {
        $json = @file_get_contents($file);
        $data = json_decode($json, true) ?: [];
    }
    $data[$slug] = ($data[$slug] ?? 0) + 1;
    @file_put_contents($file, json_encode($data, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE), LOCK_EX);
}
function interessa_most_read(int $limit = 6): array {
    $file = __interessa_views_path();
    $data = [];
    if (is_file($file)) {
        $json = @file_get_contents($file);
        $data = json_decode($json, true) ?: [];
    }
    arsort($data);
    $top = array_slice($data, 0, $limit, true);
    $titleMap = [];
    if (is_file(__DIR__ . '/articles.php')) {
        require __DIR__ . '/articles.php';
        if (isset($ART) && is_array($ART)) {
            foreach ($ART as $a) $titleMap[$a['slug']] = $a['title'];
        }
    }
    $out = [];
    foreach ($top as $slug => $count) {
        $out[] = ['slug'=>$slug, 'count'=>$count, 'title'=>$titleMap[$slug] ?? $slug];
    }
    return $out;
}
