<?php
declare(strict_types=1);
/**
 * Bočný panel – Najčítanejšie + Kategórie
 */
require_once __DIR__ . '/metrics.php';
require_once __DIR__ . '/articles.php';
require_once __DIR__ . '/functions.php';
$top = interessa_most_read(6);
?>
<aside class="sidebar">
  <section class="widget widget-popular">
    <h3>Najčítanejšie</h3>
    <ol class="popular-list">
      <?php if (empty($top)): ?>
        <li>Zatiaľ žiadne dáta. Články sa tu zobrazia po niekoľkých návštevách.</li>
      <?php else: foreach ($top as $it): ?>
        <li><a href="<?= esc(site_url('/clanky/' . $it['slug'])) ?>"><?= esc($it['title']) ?></a></li>
      <?php endforeach; endif; ?>
    </ol>
  </section>
  <section class="widget widget-cats">
    <h3>Kategórie</h3>
    <ul>
      <li><a href="<?= esc(site_url('/kategorie/proteiny')) ?>">Proteíny</a></li>
      <li><a href="<?= esc(site_url('/kategorie/kreatin')) ?>">Kreatín</a></li>
      <li><a href="<?= esc(site_url('/kategorie/pre-workout')) ?>">Pre‑workout</a></li>
      <li><a href="<?= esc(site_url('/kategorie/probiotika-travenie')) ?>">Probiotiká &amp; trávenie</a></li>
      <li><a href="<?= esc(site_url('/kategorie/vitaminy-mineraly')) ?>">Vitamíny &amp; minerály</a></li>
      <li><a href="<?= esc(site_url('/kategorie/klby-a-kolagen')) ?>">Kĺby &amp; kolagén</a></li>
      <li><a href="<?= esc(site_url('/kategorie/aminokyseliny')) ?>">Aminokyseliny</a></li>
      <li><a href="<?= esc(site_url('/kategorie/chudnutie')) ?>">Chudnutie</a></li>
    </ul>
  </section>
</aside>
