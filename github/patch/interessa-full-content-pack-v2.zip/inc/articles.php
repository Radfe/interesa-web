<?php
declare(strict_types=1);
$ART = [
  {
    "slug": "aminokyseliny-bcaa-eaa",
    "title": "Aminokyseliny BCAA EAA",
    "excerpt": "EAA majú širší význam – obsahujú všetky esenciálne AK. BCAA samé zmysel obvykle nemajú, ak máš dosť bielkovín.",
    "category": "Aminokyseliny"
  },
  {
    "slug": "bcaa-vs-eaa",
    "title": "BCAA vs. EAA",
    "excerpt": "BCAA obsahujú len 3 aminokyseliny (leucín, izoleucín, valín). EAA obsahujú všetkých 9 esenciálnych – dávajú lepší zmysel, ak riešiš anabolickú odpoveď počas dňa.",
    "category": "Aminokyseliny"
  },
  {
    "slug": "chudnutie-tip",
    "title": "Chudnutie Tip",
    "excerpt": "Základ je kalorický deficit, bielkoviny 1.6–2.2 g/kg a silový tréning. Doplnky (proteín, vláknina, kofeín) sú len pomocníci.",
    "category": "Chudnutie"
  },
  {
    "slug": "clear-protein",
    "title": "Clear Proteín",
    "excerpt": "Je to vyčírená srvátka s osviežujúcou chuťou. Hodí sa, ak ti mliečne proteíny nechutia.",
    "category": "Proteíny"
  },
  {
    "slug": "horcik",
    "title": "Horčík",
    "excerpt": "Najčastejšie citrát a bisglycinát . Oxid má slabšiu dostupnosť.",
    "category": "Vitamíny & minerály"
  },
  {
    "slug": "kedy-brat-kreatin-a-kolko",
    "title": "Kedy Brat Kreatin A Koľko",
    "excerpt": "Bežné dlhodobé dávkovanie je 3–5 g denne . Nasycovacia fáza nie je nutná, urýchli však nasýtenie svalov (20 g denne rozdelených na 4 dávky počas 5–7 dní).",
    "category": "Kreatín"
  },
  {
    "slug": "klby-a-kolagen",
    "title": "Kĺby A Kolagén",
    "excerpt": "Typ I (koža, šľachy), typ II (kĺby). Najbežnejší je hydrolyzovaný mix.",
    "category": "Kĺby & kolagén"
  },
  {
    "slug": "kolagen",
    "title": "Kolagén",
    "excerpt": "Typ I (koža, šľachy), typ II (kĺby), typ III (tkanivá). Najbežnejší je hydrolyzovaný hovädzí/morský mix.",
    "category": "Kĺby & kolagén"
  },
  {
    "slug": "kolagen-na-klby-porovnanie",
    "title": "Kolagén Na Kĺby Porovnanie",
    "excerpt": "Hydrolyzovaný kolagén (peptidy) má lepšiu vstrebateľnosť. Na kĺby sa často využíva typ II , pre pleť skôr typ I .",
    "category": "Kĺby & kolagén"
  },
  {
    "slug": "kreatin-monohydrat-vs-hcl",
    "title": "Kreatin Monohydrát vs. HCL",
    "excerpt": "Monohydrát – najviac študovaná forma, výborná cena/výkon. HCL – vyššia rozpustnosť, často menšia dávka; prínos oproti monohydrátu nie je presvedčivo lepší.",
    "category": "Kreatín"
  },
  {
    "slug": "kreatin-vedlajsie-ucinky-a-fakty",
    "title": "Kreatin Vedlajsie Ucinky A Fakty",
    "excerpt": "Monohydrát kreatínu je jedným z najlepšie preskúmaných doplnkov. Pri odporúčaných dávkach je bezpečný pre zdravých ľudí.",
    "category": "Kreatín"
  },
  {
    "slug": "najlepsie-proteiny-2025",
    "title": "Najlepšie Proteíny 2025",
    "excerpt": "Bežne 1.6–2.2 g/kg hmotnosti, zvyšok doplníš jedlom.",
    "category": "Proteíny"
  },
  {
    "slug": "pre-workout",
    "title": "Pre workout",
    "excerpt": "Sleduj denný kofeín; vyhni sa „zmesiam bez dávok“.",
    "category": "Pre‑workout"
  },
  {
    "slug": "pre-workout-ako-vybrat",
    "title": "Pre workout Ako Vybrat",
    "excerpt": "Predtréningovky – čo hľadať Kofeín: 150–300 mg podľa tolerancie. Citrulín malát: 6–8 g pre pumpu/výkon. Beta-alanín: 3.2–6.4 g denne (mravčenie je bežné).",
    "category": "Pre‑workout"
  },
  {
    "slug": "probiotika-a-travenie",
    "title": "Probiotiká A Trávenie",
    "excerpt": "Sleduj konkrétne kmene (napr. L. rhamnosus GG ), CFU a kapsuly odolné voči kyseline.",
    "category": "Probiotiká & trávenie"
  },
  {
    "slug": "probiotika-ako-vybrat",
    "title": "Probiotiká Ako Vybrat",
    "excerpt": "Probiotiká – na čo pozerať Konkrétne kmene s klinickými štúdiami (napr. Lactobacillus rhamnosus GG). Dávkovanie CFU a skladovanie (chladničné vs. stabilné formy).",
    "category": "Probiotiká & trávenie"
  },
  {
    "slug": "protein-na-chudnutie",
    "title": "Proteín Na Chudnutie",
    "excerpt": "Pri redukcii hmotnosti sleduj kalórie na porciu , podiel bielkovín a minimum pridaného cukru/tuku. Skvelá je srvátka (WPI) alebo „clear“ proteín, ak ti nevyhovuje mliečna chuť.",
    "category": "Proteíny"
  },
  {
    "slug": "proteiny",
    "title": "Proteíny",
    "excerpt": "Zbierka článkov o srvátke, izoláte, hydre, ale aj o proteíne na chudnutie či vegánskych alternatívach.",
    "category": "Proteíny"
  },
  {
    "slug": "spalovace-tukov-realita",
    "title": "Spaľovače tukov realita",
    "excerpt": "Ide zväčša o mix stimulantov a látok s malým účinkom. Kľúčom je kalorický deficit , pohyb a spánok; spaľovač môže subjektívne pomôcť s energiou/chuťou do tréningu.",
    "category": "Chudnutie"
  },
  {
    "slug": "srvatkovy-protein-vs-izolat-vs-hydro",
    "title": "Srvátkový Proteín vs. Izolát vs. Hydro",
    "excerpt": "WPC – univerzál, výborný pomer cena/výkon. WPI – menej laktózy, vyšší podiel bielkovín. WPH – predtrávený, najdrahší, chuťovo špecifický.",
    "category": "Proteíny"
  },
  {
    "slug": "vitamin-d3",
    "title": "Vitamín D3",
    "excerpt": "Bežne 1000–2000 IU denne; pri deficite podľa lekára. Praktická je kombinácia s K2 (MK-7).",
    "category": "Vitamíny & minerály"
  },
  {
    "slug": "vitamin-d3-a-imunita",
    "title": "Vitamín D3 A Imunita",
    "excerpt": "V našich zemepisných šírkach má veľa ľudí deficit. D3 sa vstrebáva lepšie s tukom a spolu s vitamínom K2 môže podporiť správne ukladanie vápnika.",
    "category": "Vitamíny & minerály"
  },
  {
    "slug": "zinek",
    "title": "Zinok",
    "excerpt": "Pri nízkom príjme z mäsa/vajec. Vyhni sa súbežnému užitiu s vysokou dávkou vápnika/železa (zhorší vstrebávanie).",
    "category": "Vitamíny & minerály"
  }
];
