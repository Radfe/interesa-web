<?php declare(strict_types=1);
$ROOT = dirname(__DIR__);
require_once $ROOT . '/inc/functions.php';

$ART = [];
@include $ROOT . '/inc/articles.php';
@include $ROOT . '/inc/articles_ext.php';

$PAGE_TITLE = 'Články – Interesa.sk';
$PAGE_DESCRIPTION = 'Všetky články o zdravej výžive, proteínoch, vitamínoch a mineráloch.';
require $ROOT . '/inc/head.php';
?>
<h1>Články</h1>

<div class="grid">
<?php foreach(array_reverse($ART,true) as $slug=>$meta):
  $title = $meta[0] ?? ucwords(str_replace('-',' ',$slug));
  $perex = $meta[1] ?? '';
  $url   = "/clanky/$slug"; ?>
  <article class="card">
    <a class="thumb" href="<?= $url ?>"><img src="/assets/img/placeholder-16x9.svg" data-src="<?= esc(article_img($slug)) ?>" alt="<?= esc($title) ?>" loading="lazy"></a>
    <div class="inner">
      <h3><a href="<?= $url ?>"><?= esc($title) ?></a></h3>
      <?php if($perex): ?><div class="meta"><?= esc($perex) ?></div><?php endif; ?>
    </div>
    <div class="actions"><a class="btn" href="<?= $url ?>">Čítať</a></div>
  </article>
<?php endforeach; ?>
</div>

<?php require $ROOT . '/inc/footer.php';
