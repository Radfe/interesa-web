<?php declare(strict_types=1);
$PAGE_TITLE = 'Interesa.sk – zdravá výživa a doplnky';
$PAGE_DESCRIPTION = 'Zdravý životný štýl, nezávislé odporúčania – proteíny, vitamíny, minerály a funkčná výživa.';
require __DIR__ . '/inc/head.php';
?>

<div class="home-layout">
  <div class="home-main">

    <!-- HERO -->
    <section class="sb-section sb-section-opt-dark has-background option-section-hero" id="domov" style="--section-height:80vh;">
      <div class="sb-background" style="background-image:
        linear-gradient(0deg,rgba(0,0,0,.7),rgba(0,0,0,.3)),
        url('https://cdn.b12.io/client_media/YgSGQPLV/ddf7484e-a74c-11f0-9993-0242ac110002-jpg-hero_image.jpeg');"></div>

      <div class="container sb-container">
        <div class="sb-hero sb-section-alignable">
          <div class="sb-hero__content-wrapper">
            <h1 class="sb-title sb-hero__title">Zdravý životný štýl</h1>
            <div class="sb-subtitle sb-hero__subtitle">Objavte výhody výživových doplnkov.</div>
          </div>
          <div class="sb-cta-wrapper sb-section-alignable">
            <a class="sb-cta-wrapper__btn sb-button sb-button--primary" href="/kategorie/">Pozrieť kategórie</a>
            <a class="sb-cta-wrapper__btn sb-button" href="/clanky/">Všetky články</a>
          </div>
        </div>
      </div>
    </section>

    <!-- TEXT + OBRÁZOK -->
    <section class="sb-section sb-section-opt-light" id="o-nas">
      <div class="container sb-container">
        <div class="sb-text-image sb-section-alignable">
          <div class="sb-text-image__content option-width">
            <div class="sb-title sb-text-image__content-title">Zdravý životný štýl</div>
            <div class="sb-subtitle sb-text-image__content-subtitle">Objavte tajomstvá výživy a fitness</div>
            <div class="sb-text-image__content-paragraph"><p>Na Interesa.sk sa zameriavame na zdravie a vitalitu.</p></div>
            <div class="sb-text-image__content-cta">
              <a class="sb-button sb-button--secondary" href="/kontakt">Kontakt</a>
            </div>
          </div>

          <div class="sb-text-image__image">
            <figure class="option-image" style="background-image:url('https://cdn.b12.io/client_media/YgSGQPLV/de0ce426-a74c-11f0-a9ce-0242ac110002-jpg-hero_image.jpeg')">
              <img alt="Smoothie" loading="lazy" src="https://cdn.b12.io/client_media/YgSGQPLV/de0ce426-a74c-11f0-a9ce-0242ac110002-jpg-hero_image.jpeg">
            </figure>
          </div>
        </div>
      </div>
    </section>

    <!-- GRID (3 karty) -->
    <section class="sb-section sb-section-opt-light" id="sluzby">
      <div class="container sb-container">
        <div class="sb-items-grid">
          <div class="sb-items-grid__content option-width sb-section-alignable">
            <div class="sb-section-title">Zdravý životný štýl</div>
            <div class="sb-section-subtitle">Podporujeme vašu cestu k zdraviu</div>
          </div>

          <ul class="sb-items-grid__items items-grid sb-section-alignable">
            <li class="items-grid__item">
              <a class="items-grid__item-body" href="/vyzivove-doplnky">
                <div class="items-grid__item-image">
                  <figure class="option-image" style="background-image:url('https://cdn.b12.io/client_media/YgSGQPLV/e5b72e4e-a74c-11f0-852c-0242ac110002-jpg-hero_image.jpeg')">
                    <img alt="" loading="lazy" src="https://cdn.b12.io/client_media/YgSGQPLV/e5d78d66-a74c-11f0-a30a-0242ac110002-jpg-regular_image.jpeg">
                  </figure>
                </div>
                <div class="items-grid__item-content">
                  <div class="items-grid__header h3">Výživové doplnky</div>
                  <div class="items-grid__description"><p>Kvalitné výživové doplnky pre zdravie.</p></div>
                </div>
              </a>
            </li>

            <li class="items-grid__item">
              <a class="items-grid__item-body" href="/fitness-poradenstvo">
                <div class="items-grid__item-image">
                  <figure class="option-image" style="background-image:url('https://cdn.b12.io/client_media/YgSGQPLV/e5bba572-a74c-11f0-97ff-0242ac110002-jpg-hero_image.jpeg')">
                    <img alt="" loading="lazy" src="https://cdn.b12.io/client_media/YgSGQPLV/e5e92f60-a74c-11f0-802a-0242ac110002-jpg-regular_image.jpeg">
                  </figure>
                </div>
                <div class="items-grid__item-content">
                  <div class="items-grid__header h3">Fitness poradenstvo</div>
                  <div class="items-grid__description"><p>Osobné poradenstvo pre dosiahnutie cieľov.</p></div>
                </div>
              </a>
            </li>

            <li class="items-grid__item">
              <a class="items-grid__item-body" href="/vitaminy-a-mineraly">
                <div class="items-grid__item-image">
                  <figure class="option-image" style="background-image:url('https://cdn.b12.io/client_media/YgSGQPLV/e5d5366e-a74c-11f0-84c9-0242ac110002-jpg-hero_image.jpeg')">
                    <img alt="" loading="lazy" src="https://cdn.b12.io/client_media/YgSGQPLV/e60415c1-a74c-11f0-8835-0242ac110002-jpg-regular_image.jpeg">
                  </figure>
                </div>
                <div class="items-grid__item-content">
                  <div class="items-grid__header h3">Vitamíny a minerály</div>
                  <div class="items-grid__description"><p>Doplnky pre podporu zdravia.</p></div>
                </div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </section>

    <!-- KONTAKT (ľavý stĺpec) -->
    <section class="sb-section sb-section-opt-light" id="kontakt">
      <div class="container sb-container">
        <div class="contact-full">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-5">
              <div class="sb-section-title sb-section-alignable">Spojte sa s nami</div>
              <div class="sb-section-subtitle sb-section-alignable">Sme tu pre vaše otázky.</div>
              <div class="contact-details vcard sb-section-alignable">
                <div class="contact-details__row contact-details__contact">
                  <div class="h3 contact-details__title">Spojte sa s nami</div>
                  <div class="contact-details__email">
                    <a class="email" href="mailto:radoslavfedorko@gmail.com">radoslavfedorko@gmail.com</a>
                  </div>
                </div>
                <div class="contact-details__row contact-details__location">
                  <div class="h3 contact-details__title">Miesto</div>
                  <p class="adr contact-details__address">Košice, SK</p>
                </div>
              </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6"><!-- rezerva na mapu/obrázok --></div>
          </div>
        </div>
      </div>
    </section>

  </div>

  <!-- PRAVÝ BOČNÝ PANEL -->
  <aside class="sidebar">
    <div class="sticky">
      <div class="widget">
        <h3>Vyhľadávanie na Heureka</h3>
        <div class="widget-body">
          <div class="heureka-affiliate-searchpanel"
               data-trixam-positionid="67512"
               data-trixam-codetype="iframe"
               data-trixam-linktarget="top"></div>
        </div>
      </div>

      <div class="widget">
        <h3>Mobily – TOP ponuky</h3>
        <div class="widget-body">
          <div class="heureka-affiliate-category"
               data-trixam-positionid="40746"
               data-trixam-categoryid="5526"
               data-trixam-categoryfilters=""
               data-trixam-codetype="iframe"
               data-trixam-linktarget="top"></div>
        </div>
      </div>
    </div>
  </aside>
</div>

<?php require __DIR__ . '/inc/footer.php';
