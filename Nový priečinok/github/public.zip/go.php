<?php
declare(strict_types=1);

/**
 * Robustné presmerovanie /go/<code> (alebo go.php?c=<code>)
 * Zdroj mapy:
 *  - inc/go-links.php (funkcia interessa_go_links() alebo go_links() alebo $GO_LINKS)
 *  - affiliate_simple_edit.csv a/alebo affiliate_links.csv (stĺpce code,url; , alebo ;)
 */

$code = trim((string)($_GET['c'] ?? ''));
if ($code === '' && isset($_SERVER['REQUEST_URI'])) {
  if (preg_match('#/go/([A-Za-z0-9\-_]+)/?#', $_SERVER['REQUEST_URI'], $m)) {
    $code = $m[1];
  }
}
$map = [];

/* 1) PHP mapa */
$inc = __DIR__ . '/inc/go-links.php';
if (is_file($inc)) {
  include_once $inc;
  if (function_exists('interessa_go_links'))      $map = (array)interessa_go_links();
  elseif (function_exists('go_links'))            $map = (array)go_links();
  elseif (isset($GO_LINKS) && is_array($GO_LINKS)) $map = $GO_LINKS;
}

/* 2) CSV override – pokryjem oba názvy súborov */
foreach (['/affiliate_simple_edit.csv','/affiliate_links.csv'] as $csvRel) {
  $csv = __DIR__.$csvRel;
  if (!is_file($csv) || !is_readable($csv)) continue;
  $fh = fopen($csv, 'r');
  if (!$fh) continue;
  $header = fgetcsv($fh, 0, ',');
  $sep = ',';
  if ($header && count($header) === 1 && strpos($header[0], ';') !== false) {
    fclose($fh); $fh = fopen($csv, 'r'); $header = fgetcsv($fh, 0, ';'); $sep = ';';
  }
  $hmap = [];
  foreach ((array)$header as $i=>$h) $hmap[$i] = strtolower(trim((string)$h));
  $iC = array_search('code', $hmap);
  $iU = array_search('url',  $hmap);
  if ($iC !== false && $iU !== false) {
    while (($row = fgetcsv($fh, 0, $sep)) !== false) {
      $c = trim((string)($row[$iC] ?? ''));
      $u = trim((string)($row[$iU] ?? ''));
      if ($c !== '' && $u !== '' && stripos($u, 'http') === 0) $map[$c] = $u;
    }
  }
  fclose($fh);
}

/* 3) Presmeruj alebo fallback */
$dst = $map[$code] ?? '';
if (is_string($dst) && (stripos($dst,'http://')===0 || stripos($dst,'https://')===0)) {
  header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
  header('Pragma: no-cache');
  header('Location: '.$dst, true, 302);
  exit;
}
header('Location: /affiliate-missing.php?code='.rawurlencode($code), true, 302);
exit;
