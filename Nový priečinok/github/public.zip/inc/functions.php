<?php declare(strict_types=1);

/** Základné helpery pre šablóny Interesa.sk */

if (!function_exists('esc')) {
  function esc(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
  }
}

if (!function_exists('site_url')) {
  function site_url(string $path = '/'): string {
    $host = $_SERVER['HTTP_HOST'] ?? 'interesa.sk';
    if ($path === '' || $path[0] !== '/') $path = '/'.$path;
    return 'https://' . $host . $path;
  }
}

if (!function_exists('asset')) {
  /**
   * Cache-busting pre statiku.
   * Použitie: asset('/assets/css/main.css')
   */
  function asset(string $rel): string {
    $root = rtrim($_SERVER['DOCUMENT_ROOT'] ?? __DIR__ . '/..', '/');
    $abs  = $root . $rel;
    $v    = is_file($abs) ? (string)filemtime($abs) : (string)time();
    return $rel . '?v=' . $v;
  }
}

if (!function_exists('article_img')) {
  function article_img(string $slug): string {
    $root = rtrim($_SERVER['DOCUMENT_ROOT'] ?? __DIR__ . '/..', '/');
    $p = $root . '/assets/img/articles/' . $slug . '.webp';
    return is_file($p) ? '/assets/img/articles/'.$slug.'.webp'
                       : '/assets/img/placeholder-16x9.svg';
  }
}
