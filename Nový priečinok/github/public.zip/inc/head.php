<?php declare(strict_types=1);
require_once __DIR__ . '/functions.php';

$PAGE_TITLE       = $PAGE_TITLE       ?? 'Interesa.sk';
$PAGE_DESCRIPTION = $PAGE_DESCRIPTION ?? 'Zdravá výživa a doplnky.';
?><!doctype html>
<html lang="sk">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= esc($PAGE_TITLE) ?></title>
<meta name="description" content="<?= esc($PAGE_DESCRIPTION) ?>">

<link rel="icon" sizes="32x32" href="/assets/img/favicon-32.png">
<link rel="apple-touch-icon" href="/assets/img/apple-touch-icon.png">

<!-- hlavné štýly -->
<link rel="stylesheet" href="<?= asset('/assets/css/main.css') ?>">
<link rel="stylesheet" href="<?= asset('/assets/css/sidebar.css') ?>">
<link rel="stylesheet" href="<?= asset('/assets/css/compat.css') ?>">

<!-- B12 vzhľad domovskej stránky -->
<link rel="stylesheet" href="<?= asset('/assets/css/home-b12.css') ?>">

<!-- drobné dorovnania vzhľadu -->
<link rel="stylesheet" href="<?= asset('/assets/css/patch.css') ?>">

<meta name="theme-color" content="#ffffff">
</head>
<body>
<header class="site-header">
  <div class="container nav-wrap">
    <a class="brand" href="/"><img src="/assets/img/logo-icon.svg" alt="" height="24"> <strong>Interesa.sk</strong></a>

    <button class="menu-toggle" aria-expanded="false" aria-controls="site-nav">Menu</button>
    <nav id="site-nav" class="top-nav" aria-label="Hlavná navigácia">
      <a href="/">Domov</a>
      <a href="/kategorie/">Kategórie</a>
      <a href="/clanky/">Články</a>
      <a href="/kontakt">Kontakt</a>
    </nav>
  </div>
</header>

<main class="container">

<script>
document.addEventListener('DOMContentLoaded', function(){
  var btn = document.querySelector('.menu-toggle');
  var nav = document.getElementById('site-nav');
  if(!btn || !nav) return;
  function closeM(){ nav.classList.remove('open'); document.body.classList.remove('menu-open'); btn.setAttribute('aria-expanded','false'); }
  function openM(){ nav.classList.add('open'); document.body.classList.add('menu-open'); btn.setAttribute('aria-expanded','true'); }
  btn.addEventListener('click', function(){ nav.classList.contains('open') ? closeM() : openM(); });
  document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeM(); });
  document.addEventListener('click', function(e){
    if(!nav.classList.contains('open')) return;
    if(e.target.closest('#site-nav') || e.target.closest('.menu-toggle')) return;
    closeM();
  });
});
</script>
