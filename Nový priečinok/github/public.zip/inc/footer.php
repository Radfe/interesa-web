<?php declare(strict_types=1); ?>
</main>

<footer class="site-footer">
  <div class="container foot-wrap">
    <div class="foot-left">
      <img src="/assets/img/logo-full.svg" alt="Interesa.sk" height="22">
      <div class="muted">© <?= date('Y') ?> Interesa.sk</div>
    </div>
    <nav class="foot-nav" aria-label="Spodná navigácia">
      <a href="/">Domov</a>
      <a href="/kategorie/">Kategórie</a>
      <a href="/clanky/">Články</a>
      <a href="/kontakt">Kontakt</a>
    </nav>
  </div>
</footer>

<script src="<?= asset('/assets/js/app.js') ?>" defer></script>
<script async src="//serve.affiliate.heurekashopping.sk/js/trixam.min.js"></script>
</body>
</html>
