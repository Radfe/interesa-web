<?php declare(strict_types=1);

/** Centrálne routovanie Interesa.sk */
require_once __DIR__ . '/inc/functions.php';

$uri  = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = '/' . trim($uri, '/');

# Domov
if ($path === '/' || $path === '/index' || $path === '/index.php') {
  require __DIR__ . '/index.php';
  exit;
}

# Články
if ($path === '/clanky' || str_starts_with($path, '/clanky/')) {
  $slug = trim(substr($path, strlen('/clanky')), '/');
  if ($slug === '' || $slug === 'index' || $slug === 'index.php') {
    require __DIR__ . '/clanky/index.php';
    exit;
  }
  if (str_ends_with($slug, '.php')) {
    $slug = substr($slug, 0, -4); // normalize .php
  }

  // 1) fyzický PHP článok
  $php = __DIR__ . "/clanky/{$slug}.php";
  if (is_file($php)) { require $php; exit; }

  // 2) obsahový HTML článok
  $html = __DIR__ . "/content/articles/{$slug}.html";
  if (is_file($html)) {
    $GLOBALS['__ARTICLE_SLUG'] = $slug;
    require __DIR__ . '/article-template.php';
    exit;
  }

  http_response_code(404);
  require __DIR__ . '/404.php';
  exit;
}

# Kategórie
if ($path === '/kategorie' || str_starts_with($path, '/kategorie/')) {
  $slug = trim(substr($path, strlen('/kategorie')), '/');
  if ($slug === '' || $slug === 'index' || $slug === 'index.php') {
    require __DIR__ . '/kategorie/index.php';
    exit;
  }
  if (str_ends_with($slug, '.php')) { $slug = substr($slug, 0, -4); }

  $php = __DIR__ . "/kategorie/{$slug}.php";
  if (is_file($php)) { require $php; exit; }

  http_response_code(404);
  require __DIR__ . '/404.php';
  exit;
}

# Krátke stránky
if ($path === '/kontakt' || $path === '/kontakt.php') { require __DIR__ . '/stranky/kontakt.php'; exit; }

# Fallback: ak je to priamo PHP
$direct = __DIR__ . $path;
if (is_file($direct) && str_ends_with($direct, '.php')) { require $direct; exit; }

http_response_code(404);
require __DIR__ . '/404.php';
