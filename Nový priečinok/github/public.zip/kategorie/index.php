<?php declare(strict_types=1);
$ROOT = dirname(__DIR__);

/* Dáta článkov */
$ART = [];
@include $ROOT . '/inc/articles.php';
@include $ROOT . '/inc/articles_ext.php';

$PAGE_TITLE       = 'Kategórie – Interesa.sk';
$PAGE_DESCRIPTION = 'Kategórie článkov o zdravej výžive, proteínoch, vitamínoch, mineráloch a imunite.';

require $ROOT . '/inc/head.php';

/* Kategórie (kľúč => názov) */
$CATS = [
  'imunita'    => 'Imunita',
  'klby-koža' => 'Kĺby-koža',
  'mineraly'   => 'Minerály',
  'proteiny'   => 'Proteíny',
  'sila'       => 'Sila',
  'vyziva'     => 'Výživa',
];

/* Počty článkov podľa kategórií */
$catCounts = [];
foreach ($ART as $slug=>$meta) {
  $k = $meta[2] ?? '';
  if ($k) $catCounts[$k] = ($catCounts[$k] ?? 0) + 1;
}
?>
<div class="layout-2col container">
  <main class="content-main">
    <h1>Kategórie</h1>
    <div class="list">
      <?php foreach($CATS as $key=>$label): ?>
        <div class="card" style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;margin:12px 0;">
          <div>
            <div style="font-weight:600;"><?= htmlspecialchars($label,ENT_QUOTES) ?></div>
            <div class="muted"><?= (int)($catCounts[$key] ?? 0) ?> článkov</div>
          </div>
          <a class="btn" href="/kategorie/<?= urlencode($key) ?>.php">Zobraziť</a>
        </div>
      <?php endforeach; ?>
    </div>
  </main>

  <?php include $ROOT . '/inc/sidebar.php'; ?>
</div>

<?php require $ROOT . '/inc/footer.php';
