<?php
declare(strict_types=1);
$PAGE_TITLE = 'Stránka sa nenašla | Interesa.sk';
$PAGE_DESCRIPTION = 'Hľadaná stránka neexistuje.';
require __DIR__ . '/inc/head.php';
http_response_code(404);
?>
<h1>404 – stránka sa nenašla</h1>
<p class="note">Skontroluj adresu alebo prejdi na <a href="/">Domov</a>.</p>
<?php require __DIR__ . '/inc/footer.php';
