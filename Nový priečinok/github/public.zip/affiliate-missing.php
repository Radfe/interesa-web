<?php
declare(strict_types=1);
require __DIR__ . '/inc/head.php';
$code = htmlspecialchars((string)($_GET['code'] ?? ''), ENT_QUOTES, 'UTF-8');
?>
<section class="content-main">
  <div class="container">
    <h1>Odkaz bude čoskoro dostupný</h1>
    <p>Pre kód <code><?= $code ?></code> zatiaľ nemáme priradený affiliate deeplink. Čoskoro ho doplníme.</p>
    <p>Medzitým si môžete pozrieť <a href="/clanky/">všetky články</a> alebo <a href="/">Domov</a>.</p>
  </div>
</section>
<?php require __DIR__ . '/inc/footer.php'; ?>
