(function(){
  document.addEventListener('DOMContentLoaded', function(){
    var btn = document.querySelector('.menu-toggle');
    var nav = document.getElementById('site-nav');
    if(!btn || !nav) return;
    function closeM(){ nav.classList.remove('open'); document.body.classList.remove('menu-open'); btn.setAttribute('aria-expanded','false'); }
    function openM(){ nav.classList.add('open'); document.body.classList.add('menu-open'); btn.setAttribute('aria-expanded','true'); }
    btn.addEventListener('click', function(){ nav.classList.contains('open') ? closeM() : openM(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeM(); });
    document.addEventListener('click', function(e){
      if(!nav.classList.contains('open')) return;
      if(e.target.closest('#site-nav') || e.target.closest('.menu-toggle')) return;
      closeM();
    });
  });
})();
